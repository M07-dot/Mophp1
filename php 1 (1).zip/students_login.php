<?php
include 'functions.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $students = loadFromJSON('json/students.json');
    foreach ($students as $student) {
        if ($student['email'] === $email && password_verify($password, $student['hashed_password'])) {
            $_SESSION['student'] = $student;
            setcookie("user", $email, time() + (86400 * 30), "/"); // حفظ الكوكيز لمدة 30 يومًا
            header("Location: dashboard.php");
            exit;
        }
    }
    $error = "بيانات الدخول غير صحيحة!";
}
?>
<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>تسجيل دخول الطلاب</title>
</head>
<body>
    <form method="post" action="">
        <h2>تسجيل دخول الطلاب</h2>
        <?php if (!empty($error)) echo "<p class='error'>$error</p>"; ?>
        <input type="email" name="email" placeholder="البريد الإلكتروني" required>
        <input type="password" name="password" placeholder="كلمة المرور" required>
        <button type="submit">تسجيل الدخول</button>
    </form>
</body>
</html>