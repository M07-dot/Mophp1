<?php
include 'functions.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $teachers = loadFromJSON('json/teachers.json');
    foreach ($teachers as $teacher) {
        if ($teacher['email'] === $email && password_verify($password, $teacher['hashed_password'])) {
            $_SESSION['teacher'] = $teacher;
            setcookie("teacher", $email, time() + (86400 * 30), "/"); // حفظ الكوكيز
            header("Location: dashboard.php");
            exit;
        }
    }
    $error = "بيانات الدخول غير صحيحة!";
}
?>
<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>تسجيل دخول المعلمين</title>
</head>
<body>
    <form method="post" action="">
        <h2>تسجيل دخول المعلمين</h2>
        <?php if (!empty($error)) echo "<p class='error'>$error</p>"; ?>
        <input type="email" name="email" placeholder="البريد الإلكتروني" required>
        <input type="password" name="password" placeholder="كلمة المرور" required>
        <button type="submit">تسجيل الدخول</button>
    </form>
</body>
</html>