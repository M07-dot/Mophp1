<?php
include 'functions.php';
session_start();

if (!isset($_SESSION['teacher'])) {
    header("Location: teachers_login.php");
    exit;
}

$students = loadFromJSON('json/students.json');
?>
<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>لوحة تحكم المعلمين</title>
</head>
<body>
    <h1>مرحبًا، <?php echo $_SESSION['teacher']['name']; ?>!</h1>
    <h2>إدارة الطلاب</h2>
    <table>
        <thead>
            <tr>
                <th>الاسم</th>
                <th>السنة</th>
                <th>البلد</th>
                <th>إجراءات</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($students as $student): ?>
            <tr>
                <td><?php echo $student['name']; ?></td>
                <td><?php echo $student['year']; ?></td>
                <td><?php echo $student['country']; ?></td>
                <td>
                    <a href="transfer_student.php?id=<?php echo $student['id']; ?>">نقل</a>
                    <a href="update_student.php?id=<?php echo $student['id']; ?>">تعديل</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <a href="logout.php">تسجيل الخروج</a>
</body>
</html>