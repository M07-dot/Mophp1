<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>نظام إدارة الطلاب</title>
</head>
<body>
    <header>
        <h1>مرحبًا بكم في نظام إدارة الطلاب</h1>
    </header>
    <main>
        <div class="options">
            <a href="students_register.php">تسجيل طالب جديد</a>
            <a href="teachers_register.php">تسجيل معلم جديد</a>
            <a href="students_login.php">تسجيل دخول الطلاب</a>
            <a href="teachers_login.php">تسجيل دخول المعلمين</a>
        </div>
    </main>
</body>
</html>