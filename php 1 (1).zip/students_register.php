<?php
include 'functions.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $parent_phone = $_POST['parent_phone'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    $year = $_POST['year'];
    $country = $_POST['country'];

    $student = [
        'name' => $name,
        'phone' => $phone,
        'parent_phone' => $parent_phone,
        'email' => $email,
        'password' => $password,
        'hashed_password' => $hashed_password,
        'year' => $year,
        'country' => $country,
    ];

    saveToJSON('json/students.json', $student);
    insertStudent($student); // حفظ في MySQL
    $_SESSION['message'] = "تم تسجيل الطالب بنجاح!";
    header("Location: students_login.php");
}
?>
<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>تسجيل الطلاب</title>
</head>
<body>
    <form method="post" action="">
        <h2>تسجيل طالب جديد</h2>
        <input type="text" name="name" placeholder="الاسم الرباعي" required>
        <input type="text" name="phone" placeholder="رقم الهاتف" required>
        <input type="text" name="parent_phone" placeholder="رقم هاتف ولي الأمر" required>
        <input type="email" name="email" placeholder="البريد الإلكتروني" required>
        <input type="password" name="password" placeholder="كلمة المرور" required>
        <select name="year" required>
            <option value="أولى إعدادي">أولى إعدادي</option>
            <option value="ثانية إعدادي">ثانية إعدادي</option>
            <option value="ثالثة إعدادي">ثالثة إعدادي</option>
            <option value="أولى ثانوي">أولى ثانوي</option>
            <option value="ثانية ثانوي">ثانية ثانوي</option>
            <option value="ثالثة ثانوي">ثالثة ثانوي</option>
        </select>
        <input type="text" name="country" placeholder="البلد" required>
        <button type="submit">تسجيل</button>
    </form>
</body>
</html>